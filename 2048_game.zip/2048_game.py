import tkinter as tk
from tkinter import messagebox
import random
import copy


SIZE = 4

def init_board():
    board = [[0] * SIZE for _ in range(SIZE)]
    add_random_tile(board)
    add_random_tile(board)
    return board

def add_random_tile(board):
    empty_tiles = [(r, c) for r in range(SIZE) for c in range(SIZE) if board[r][c] == 0]
    if empty_tiles:
        r, c = random.choice(empty_tiles)
        board[r][c] = random.choice([2, 4])

def compress(board):
    new_board = [[0] * SIZE for _ in range(SIZE)]
    for r in range(SIZE):
        pos = 0
        for c in range(SIZE):
            if board[r][c] != 0:
                new_board[r][pos] = board[r][c]
                pos += 1
    return new_board

def merge(board):
    for r in range(SIZE):
        for c in range(SIZE - 1):
            if board[r][c] == board[r][c + 1] and board[r][c] != 0:
                board[r][c] *= 2
                board[r][c + 1] = 0
    return board

def reverse(board):
    new_board = []
    for r in range(SIZE):
        new_board.append(list(reversed(board[r])))
    return new_board

def transpose(board):
    new_board = []
    for c in range(SIZE):
        new_row = []
        for r in range(SIZE):
            new_row.append(board[r][c])
        new_board.append(new_row)
    return new_board

def move_left(board):
    new_board = compress(board)
    new_board = merge(new_board)
    new_board = compress(new_board)
    return new_board

def move_right(board):
    new_board = reverse(board)
    new_board = move_left(new_board)
    new_board = reverse(new_board)
    return new_board

def move_up(board):
    new_board = transpose(board)
    new_board = move_left(new_board)
    new_board = transpose(new_board)
    return new_board

def move_down(board):
    new_board = transpose(board)
    new_board = move_right(new_board)
    new_board = transpose(new_board)
    return new_board

class Game2048:
    def __init__(self, master):
        self.master = master
        self.master.title("2048 Game")
        self.board = init_board()
        self.previous_board = None

        self.grid_frame = tk.Frame(self.master)
        self.grid_frame.grid()

        self.tiles = [[tk.Label(self.grid_frame, text='', width=4, height=2, font=('Helvetica', 24), bg='white', borderwidth=2, relief="groove") for _ in range(SIZE)] for _ in range(SIZE)]

        for r in range(SIZE):
            for c in range(SIZE):
                self.tiles[r][c].grid(row=r, column=c, padx=5, pady=5)

        self.update_gui()

        self.master.bind("<Up>", self.move_up)
        self.master.bind("<Down>", self.move_down)
        self.master.bind("<Left>", self.move_left)
        self.master.bind("<Right>", self.move_right)

        undo_button = tk.Button(self.master, text="Undo", command=self.undo)
        undo_button.grid(row=SIZE, column=0, columnspan=SIZE, sticky='we')

    def save_state(self):
        self.previous_board = copy.deepcopy(self.board)

    def undo(self):
        if self.previous_board:
            self.board = self.previous_board
            self.previous_board = None
            self.update_gui()
        else:
            messagebox.showinfo("Info", "No move to undo.")

    def move(self, direction_func):
        self.save_state()
        self.board = direction_func(self.board)
        add_random_tile(self.board)
        self.update_gui()
        if not self.can_move():
            messagebox.showinfo("Game Over", "No more valid moves!")

    def move_up(self, event):
        self.move(move_up)

    def move_down(self, event):
        self.move(move_down)

    def move_left(self, event):
        self.move(move_left)

    def move_right(self, event):
        self.move(move_right)

    def update_gui(self):
        for r in range(SIZE):
            for c in range(SIZE):
                value = self.board[r][c]
                self.tiles[r][c].config(text=str(value) if value != 0 else '')
                self.tiles[r][c].config(bg=self.get_tile_color(value))

    def get_tile_color(self, value):
        colors = {
            0: "#cdc1b4", 2: "#eee4da", 4: "#ede0c8", 8: "#f2b179", 
            16: "#f59563", 32: "#f67c5f", 64: "#f65e3b", 128: "#edcf72", 
            256: "#edcc61", 512: "#edc850", 1024: "#edc53f", 2048: "#edc22e"
        }
        return colors.get(value, "#3c3a32")

    def can_move(self):
        for r in range(SIZE):
            for c in range(SIZE):
                if self.board[r][c] == 0:
                    return True
                if r < SIZE - 1 and self.board[r][c] == self.board[r + 1][c]:
                    return True
                if c < SIZE - 1 and self.board[r][c] == self.board[r][c + 1]:
                    return True
        return False

if __name__ == "__main__":
    root = tk.Tk()
    game = Game2048(root)
    root.mainloop()

